
By default StatPlanet will use the PHP version. If your web server is configured to use ASPX files,
you would also need to change the following setting in the StatPlanet Data Editor, sheet 'settings':

- Setting: "EXPLANG", in the section 'Export options'
- Value: change from 'php' to 'aspx'